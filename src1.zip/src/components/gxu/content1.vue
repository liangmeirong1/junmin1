
<template>
  <div class="content1">
    <ul class="good-list">
      <li v-for="item of infolist" :key="item.id" @click="handel(item.id)">
        <div class="left con">
          <div class="name">
            <span class="iconfont5 icon-fasong"></span>{{ item.title }}
            <span class="tag">正在对接</span>
          </div>
          <div class="appNum">{{ item.detail.substr(0,40) }}...</div>
        </div>
        <div class="right">{{ item.time }}</div>
      </li>
    </ul>
    <div class="pagination1">
      <el-pagination background 
      layout="prev, pager, next,total" 
      @current-change="handlePageNumChange"
      :total="60">
      </el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: "content1",
  components: {},
  methods: {
     handel(id) {
      this.$router.push({
        name: "demdetails",
        params: { id },
      });
    },
    handlePageNumChange(val) {
      this.$emit("pageNumChange", val);
    },
  },
  data() {
    return {
      infolist: [
        {
          id: "001",
          title: "大扩展比方舱移动医院系统集成技术",
          detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时",
          time: "12月30日",
        },
        {
          id: "002",
          title: "大扩展比方舱移动医院系统集成技术",
           detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时，同一订单纸箱规格大小",
          time: "12月30日",
        },
        {
          id: "003",
          title: "大扩展比方舱移动医院系统集成技术",
          detail: "当前电商行业及产品终端分",
          time: "12月30日",
        },
        {
          id: "004",
          title: "大扩展比方舱移动医院系统集成技术",
           detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时，同一订单纸箱规格大小端分销的纸箱在托盘上码垛作业时",
          time: "12月30日",
        },
        {
          id: "005",
          title: "大扩展比方舱移动医院系统集成技术",
          detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时，同一",
          time: "12月30日",
        },
        {
          id: "006",
          title: "大扩展比方舱移动医院系统集成技术",
           detail: "当前电商行业及产品终端分销的纸箱在",
          time: "12月30日",
        },
        {
          id: "007",
          title: "大扩展比方舱移动医院系统集成技术",
          detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时，同一订单纸箱规格大小",
          time: "12月30日",
        },
      ],
    };
  },
};
</script>
<style  scoped>
.content1 {
  width: 100%;
}

.good-list li {
  display: flex;
  padding: 10px;
  border-bottom: 1px dotted rgb(199, 199, 199);
  color: rgb(145, 143, 143);
  font-size: 14px;
  height: 70px;
 cursor: pointer!important;
}
.con {
  flex: 1;
}
.left {
  text-align: left;
  margin-left: 10px;
  padding: 10px 0 0 0;
}
.name {
  color: black;
  font-size: 16px;
}
.appNum{
  margin-top: 8px;
}
.tag {
  line-height: 24px;
  display: inline-block;
  vertical-align: middle;
  padding: 0 8px;
  border-radius: 4px;
  font-size: 13px;
  margin-left: 10px;
  color: #e62e2e;
  background: #fceaea;
}
.iconfont5 {
  font-size: 17px;
  color: #323b50;
}
.pagination1 {
  height: 70px;
  float: right;
  padding-top: 25px;

  align-content: right;
}

.pagination1
  >>> .el-pagination.is-background
  .el-pager
  li:not(.disabled).active {
  background-color: #323b50;
  color: #fff;
}
.pagination1 >>> .el-pagination.is-background .el-pager li:hover {
  color: #000000;
}

</style>