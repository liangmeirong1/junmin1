
<template>
  <div class="content1">
    <ul class="good-list">
      <li v-for="item of infolist" :key="item.id" @click="handel(item.id)">
        <div class="left con">
          <div class="name">
            <span class="iconfont5 icon-fasong"></span>{{ item.title }}
          </div>
          <div class="appNum">{{ item.type }}</div>
        </div>
        <div class="right">{{ item.time }}</div>
      </li>
    </ul>
    <div class="pagination1">
      <el-pagination background 
      layout="prev, pager, next,total" 
      @current-change="handlePageNumChange"
      :total="60">
      </el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: "content3",
  components: {},
  methods: {
     handel(id) {
      this.$router.push({
        name: "junpindetails",
        params: { id },
      });
    },
    handlePageNumChange(val) {
      this.$emit("pageNumChange", val);
    },
  },
  data() {
    return {
      infolist: [
        {
          id: "001",
          title: "FPGA信号预处理开发（二次发布）",
          type: "研究技术类",
          time: "12月30日",
        },
        {
          id: "002",
          title: "便携式接收处理分析设备（二次发布）",
           type: "产品设备类",
          time: "12月30日",
        },
        {
          id: "003",
          title: "10MHz有源功分设备",
          type: "产品设备类",
          time: "12月30日",
        },
        {
          id: "004",
          title: "国产化双通道超短波CPCI下变频卡",
           type: "器件器材类",
          time: "12月30日",
        },
        {
          id: "005",
          title: "双通道X/L下变频器",
          type: "产品设备类",
          time: "12月30日",
        },
        {
          id: "006",
          title: "国产化四通道CPCI卫星下变频卡",
           type: "器件器材类",
          time: "12月30日",
        },
        {
          id: "007",
          title: "某型装备实装发射站训练测传系统",
          type: "系统工程类",
          time: "12月30日",
        },
      ],
    };
  },
};
</script>
<style  scoped>
.content1 {
  width: 100%;
}

.good-list li {
  display: flex;
  padding: 10px;
  border-bottom: 1px dotted rgb(199, 199, 199);
  color: rgb(145, 143, 143);
  font-size: 14px;
  height: 70px;
 cursor: pointer!important;
}
.con {
  flex: 1;
}
.left {
  text-align: left;
  margin-left: 10px;
  padding: 10px 0 0 0;
}
.name {
  color: black;
  font-size: 16px;
}
.appNum{
  margin-top: 8px;
}
.tag {
  line-height: 24px;
  display: inline-block;
  vertical-align: middle;
  padding: 0 8px;
  border-radius: 4px;
  font-size: 13px;
  margin-left: 10px;
  color: #e62e2e;
  background: #fceaea;
}
.iconfont5 {
  font-size: 17px;
  color: #323b50;
}
.pagination1 {
  height: 70px;
  float: right;
  padding-top: 25px;

  align-content: right;
}

.pagination1
  >>> .el-pagination.is-background
  .el-pager
  li:not(.disabled).active {
  background-color: #323b50;
  color: #fff;
}
.pagination1 >>> .el-pagination.is-background .el-pager li:hover {
  color: #000000;
}

</style>