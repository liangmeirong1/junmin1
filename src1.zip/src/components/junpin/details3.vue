<template>
  <div class="content1">
    <div class="top">
      <div class="title">
        <span class="iconfont5 icon-fasong"></span>FPGA信号预处理开发（二次发布）
      </div>
    
    </div>
    <table class="table" border="1">
      <tbody>
          <tr>
          <td class="td_head">发布单位</td>
          <td>战略支援部队</td>
        </tr>
        <tr>
          <td class="td_head">需求类型</td>
          <td>研究技术类</td>
        </tr>
           <tr>
          <td class="td_head">统一编码</td>
          <td>1234556</td>
        </tr>
        <tr>
          <td class="td_head">发布日期</td>
          <td>2020-12-30</td>
        </tr>
        <tr>
          <td class="td_head">具体信息</td>
          <td>
            (<a  href="http://www.weain.mil.cn/cgxq/jdxq/1327167532950364162.shtml?v=20201113163252&demandMark=1" target="_blank">请点击</a>)
          </td>
         
        </tr>
      </tbody>
    </table>
  </div>
    
</template>

<script>
/* import top from '../components/top' */

export default {
  name: "junpindetails",
  components: {},
  data() {
    return {
      name: "user",
      params: { userId },
    };
  },
};
</script>
<style scoped>
* {
  box-sizing: border-box;
}
.content1 {
  width: 95%;
  margin: 25px auto;
  font-size: 16px;
}

.title {
 
  text-align: left;
  font-size: 20px;
}
.iconfont5 {
  font-size: 17px;
  color: #323b50;
  margin-right: 10px;
}

tbody {
  display: table-row-group;
  vertical-align: middle;
  text-align: left;
}
td {
  padding-left: 25px;
}
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  margin-top: 25px;
  height: 150px;
}
.table .td_head {
  color: #333333;
  width:200px;
  height: 50px;
  background: #ebebeb;
  text-align: center;
}

</style>