<template>

  <div id="demand">
    <div class="left"><left /></div>

    <div class="content">
     <junpinnav  @changeNav="handleChangeNav"/>
     <content3/>
    </div>
 
  </div>
 
    
</template>

<script>
import left from "../components/junpin/left";
 import content3 from "../components/junpin/content3"
  import junpinnav from "../components/junpin/junpinnav"
import axios from 'axios'


export default {
  name: "Militaryprocure",
  components: { left,junpinnav,content3},
  data() {
    return {
    select2:{ 
      unit:" ",
     type:" ",},
      id: null,
    
      page: {
      pageSize: 10,
      pageNum: 1,
      total: 0
      },
      serverList: []
    };
  },
  mounted() {
    this.id = this.$route.params.id
    this.getList()
  },
   watch: {
    $route: {
      handler(nv, ov) {
        
        this.id = this.$route.params.id;
        this.getList();
      },
      // 深度观察监听
      deep: true,
    },
  },
  methods: {
    getList() {
      axios
        .get("/api/getData", {
          params: {
            id: this.id,
            publicUnit:select1.publicUnit,
            demandType:select1.demandType,
            pageSize: this.page.pageSize,
            pageNum: this.page.pageNum,
          },
        })
        .then((res) => {
          if (res) {
            this.serverList = res.data.list;
            this.page.total = res.data.total;
          } else {
            console.log("没有数据");
          }
        });
    },
    // 服务领域改变
    handleChangeNav(p) {
      this.select2 = p;
      alert(this.select2.type+this.select2.unit);
      this.getList();
    },

    // 页码改变
    handlePageNumChange(val) {

      this.page.pageNum = val;
      this.getList();
    },
  },
};
</script>
<style scoped>
#demand {
  width: 80%;
  position: relative;
  left: 10%;
 /*  border: 1px solid rgb(235, 235, 235); */
  display: flex;
  overflow: hidden;
  margin-top: 10px;
}
.left {
  width: 21%;
}
.content {
  border: 1px solid rgb(235, 235, 235);
  flex: 1;
  margin-left: 15px;
  
}
</style>