<template>
  <div id="newinfo">
    <top/>
    <router-view/>
    <FriLink/>
    <NavBottom/>
  
   
  </div>
</template>

<script>
import top from '../components/top'
  import FriLink from '../components/FriLink'
import NavBottom from '../components/NavBottom'

export default {
  name: "newinfo",
  components:{top,FriLink,NavBottom,},
  data () {
      return{
          msg:'1'
      }
  }
}
</script>
