
<template>
  <div class="content1">
    <ul class="good-list">
      <li v-for="item of infolist" :key="item.id" @click="handel(item.id)">
        <div class="pic">
          <img :src="item.img" />
        </div>
        <div class="left">
          <div class="name">
            {{ item.title }}
          </div>
          <div>{{ item.detail.substr(0,30)}}...</div>
        </div>
      </li>
    </ul>
    <div class="pagination1">
      <el-pagination background layout="prev, pager, next,total" :total="60">
      </el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: "content2",
  components: {},
  methods: {
    handel(id) {
      this.$router.push({
        name: "providetail",
        params: { id: id },
      });
    },
  },
  data() {
    return {
      infolist: [
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "001",
          title: "遥控深海采矿车",
          detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "002",
          title: "遥控深海采矿车",
         detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "003",
          title: "遥控深海采矿车",
         detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "004",
          title: "遥控深海采矿车",
          detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "005",
          title: "遥控深海采矿车",
         detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "006",
          title: "遥控深海采矿车",
          detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "007",
          title: "遥控深海采矿车",
         detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "008",
          title: "遥控深海采矿车",
          detail: "当前电商行业及产品终端分销的纸箱在托盘上码垛作业时",
          time: "12月30日",
        },
      ],
    };
  },
};
</script>
<style  scoped>
.content1 {
  width: 100%;
  margin: 0 auto;
}

.good-list {
  display: flex;
  flex-flow: row wrap;
  justify-content: start;
}
.name{
  color: #000000;
  font-size:16px;
  padding: 5px;
}

.good-list li {
  cursor: pointer;
  width: 31%;
  box-sizing: border-box;
  margin: 0 1.1%;
  padding: 10px;
  border: 0.5px solid rgb(199, 199, 199);
  color: rgb(145, 143, 143);
  font-size: 14px;
  margin-top: 25px;
}
.good-list li:hover {
  box-shadow: 0 0 2px 2px rgb(211, 211, 211) ;
}
.pic img {
  width: 100%;
}

.pagination1 {
  height: 70px;
  float: right;
  padding-top: 25px;
  align-content: right;
}

.pagination1
  >>> .el-pagination.is-background
  .el-pager
  li:not(.disabled).active {
  background-color: #323b50;
  color: #fff;
}
.pagination1 >>> .el-pagination.is-background .el-pager li:hover {
  color: #000000;
}
</style>