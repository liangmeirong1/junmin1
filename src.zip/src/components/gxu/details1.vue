
<template>
  <div class="content1">
    <div class="top">
      <div class="title">
        <span class="iconfont5 icon-fasong"></span>多箱型自动码垛机
      </div>
    
    </div>
    <table class="table" border="1">
      <tbody>
        <tr>
          <td class="td_head">单位（个人）名称：</td>
          <td colspan="3">安徽军民融合公共服务平台</td>
        </tr>
        <tr>
          <td class="td_head">需求类型</td>
          <td>产品需求</td>
          <td class="td_head">发布日期</td>
          <td>2020-03-31</td>
        </tr>
        <tr>
          <td class="td_head">联系人</td>
          <td>
            梁***(请<router-link  to="/register">登录</router-link>后查看)
          </td>
          <td class="td_head">联系电话</td>
          <td>183***7</td>
        </tr>
      </tbody>
    </table>
    <div class="infodetail">
      <el-tabs type="border-card">
        <el-tab-pane>
          <span slot="label">需求描述</span>
          在实际工作中，该水果套网包装机分为定位输送区和塑料发泡网套网区这两个区域。
        </el-tab-pane>
        <el-tab-pane label="具体要求">机械系统主要由定位输送装置及间歇式套网机构以及水果呈放装置组成；整个运行过程是分选后的水果进入到定位输送装置中的定位果盘上，水果依靠输送装置中链输送的轻微振动来实现果梗垂直于水平面的自动位；水果完成定位后在定位果盘中随着输送链的转动而进行运动，进入塑料发泡网套网区，光电限位开关检测其到达套网位置，输送链转动立即停止；套网装置中的双作用气爪以及气缸在 PLC 的控制下夹着撑网筒向下运动同时间歇式套网机构插刀在电机带动下向上运动，当光电限位开关检测到两者达到同一水平高度，插刀带着发泡网下降至下限位，同时双作用气缸带着撑网筒到达上限位，最后塑料光纤切割刀在推动气缸的作用下割断发泡网，套网结束；在整个水果套网包装机运动过程中，能完成预期的水果套网包装功能。</el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
/* import top from '../components/top' */

export default {
  name: "details1",
  components: {},
  data() {
    return {
      name: "user",
      params: { userId },
    };
  },
};
</script>
<style scoped>
* {
  box-sizing: border-box;
}
.content1 {
  width: 95%;
  margin: 25px auto;
  font-size: 16px;
}

.title {
 
  text-align: left;
  font-size: 20px;
}
.iconfont5 {
  font-size: 17px;
  color: #323b50;
  margin-right: 10px;
}

tbody {
  display: table-row-group;
  vertical-align: middle;
  text-align: left;
}
td {
  padding-left: 25px;
}
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  margin-top: 25px;
  height: 150px;
}
.table .td_head {
  color: #333333;
  width: 175px;
  background: #ebebeb;
}
.infodetail {
  
  margin-top: 25px;
}
.infodetail >>> .el-tabs--border-card {
border: 1px solid #dadada;
    box-shadow: none;
}
.infodetail >>> .el-tabs--border-card>.el-tabs__header {
    background-color:  #dadada;
    font-size: 16px !important;
    
    margin: 0;
}

 .infodetail >>> .el-tabs--border-card>.el-tabs__header .el-tabs__item.is-active {
    color: #ffffff;
    background-color: #323b50;
}
.infodetail >>> .el-tabs--border-card>.el-tabs__header .el-tabs__item:not(.is-disabled):hover {
    color: #ffffff;
}
.infodetail >>> .el-tabs__item {
    font-size: 16px;
   
}
.el-tab-pane{
  text-align: left;
}
</style>