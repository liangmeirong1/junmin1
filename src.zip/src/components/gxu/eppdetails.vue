<template>
  <div id="eppdetails">
    <div class="title">
        <h2>{{list.title}}</h2>
        <div class="detail"><span>发布时间:{{list.date}}</span>&nbsp;<span>来源:{{list.source}}</span>&nbsp;<span>阅读:{{list.readtimes}}</span></div>
        </div>
    <div class="cont" v-html="list.content"></div>

  </div>
</template>

<script>

export default {
  name: 'eppdetails',
  data () {
    return {
     list:{
         title:"一网畅行—复工复产通用管理系统",
         date:"2020-02-25",
         source:"中电科",
         readtimes:234,
         content:"一、红外热成像体温快速筛查监测  <br>主要功能:配置AI智能型红外热成像人体体温快速筛查系统和车载型红外热成像分析系统，在机场、车站、医院、学校、机关事业单位、集团总部等人员流动密集区域，实现高精度、大面积、全角度的发热人员快速筛查和精度识别。<br>技术参数<br>1、高精度进口8-14μm长坡红外焦平面阵列探测器（384*288或640*480）；<br>2、自主研发的AI智能人体体温筛查核心算法及内置温度补偿功能；<br>3、体温测量精度可以达到±0.3℃。<br>二、疫情期间水质应急监测  <br>主要功能 <br>针对生态环境部印发的《应对新型冠状病毒感染肺炎疫情应急监测方案》，天麓公司的疫情防控应急监测车配置了便携式分析仪器和车载型全自动分析仪，实现医疗废水、城镇污水、地表水（含水源地水）及生活饮用水中的pH、CODcr、余氧/总氧、生物毒性和粪大肠菌群等指标地现场快速便携监测和移动定点全自动连续检测组合，满足疫情期间水质应急监测要求。 <br>三、业务联系：<br>刘经理：13873178031<br>龙经理：18874222032"
         }}
    

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/* #eppdetails{
   
    border:1px solid red;
} */
.title{
    width: 95%;
    margin: 10px auto;
    background-color: rgb(231, 231, 231);
    height: 90px;
    padding-top: 20px;
}
.detail{
    padding-top:10px;

}
.detail span{
    padding:10px; 
    font-weight: lighter;
}
.cont{
    padding: 20px;
    text-align: left;
}

</style>