
<template>
  <div class="top">
    <div class="con">
      <img
        src="https://www.hnjmrh.gov.cn/file/M00+01+04+rBAHAlw4BZ-AaQ9tAAB0-JM4h4I228.jpg"
      />
      <div class="detail">
        <h2>list.title</h2>
        <div class="pa">单位（个人）名称：list.unit</div>
        <div class="pa">设备类型：国防最高标准器具\</div>
        <div class="pa">安装地点：南海区</div>
        <div class="pa">价格（人民币/万元）：面议</div>
        <div class="pa">服务费（人民币/万元）：800</div>
        <div class="pa"> 联系人：梁**(请<router-link to="/register">登录</router-link>后查看)
        </div>
        <div class="pa">联系电话：134*****4556</div>
      </div>
    </div>
    <div class="infodetail">
      <el-tabs type="border-card">
        <el-tab-pane>
          <span slot="label">设备描述</span>
          <div v-html="list.detail">
       </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
/* import top from '../components/top' */

export default {
  name: "details2",
  components: {},
  data() {
    return {
      list: {
        title:"遥控深海采矿车",
        unit:"安徽军民融合公共服务平台",
        devicetype:"国防最高标准器具",
        area:"南海区",
        price:"面议",
        fuwu:"800",
        man:"梁**",
        phone:"134*****4556",
        detail:" 1.可视化激光码型测试仪。 <br />波长范围：200～1600nm； <br />码型：3～10位编码； <br />重频：≤100Hz； <br />脉冲宽度：≤15ns<br />2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。<br />3.资质要求：具有武器装备承制单位资格。"




      },
     
        
      
    };
  },
};
</script>
<style scoped>
.top {
  width: 100%;

  padding: 15px;
}
.con {
  width: 100%;
  display: flex;
  height: 360px;
}
.top img {
  width: 48%;
  height:320px ;
}
h2 {
  padding-top: 10px;
  color: #323b50;
}
.pa {
  padding: 17px 0 0 10px;
}

.detail {
  text-align: left !important;
  padding-left: 18px;
  flex: 1;
  color: #131313;
}
.infodetail {
  margin-top: 25px;
}
.infodetail >>> .el-tabs--border-card {
  border: 1px solid #dadada;
  box-shadow: none;
}
.infodetail >>> .el-tabs--border-card > .el-tabs__header {
  background-color: #dadada;
  font-size: 16px !important;

  margin: 0;
}

.infodetail
  >>> .el-tabs--border-card
  > .el-tabs__header
  .el-tabs__item.is-active {
  color: #ffffff;
  background-color: #323b50;
}
.infodetail
  >>> .el-tabs--border-card
  > .el-tabs__header
  .el-tabs__item:not(.is-disabled):hover {
  color: #ffffff;
}
.infodetail >>> .el-tabs__item {
  font-size: 16px;
}
.el-tab-pane {
  text-align: left;
}
</style>