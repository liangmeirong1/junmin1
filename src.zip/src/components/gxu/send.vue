<template>
  <div class="form1">
    <form action="#" method="post" id="formMsg">
      <table border="0" cellpadding="" cellspacing="0">
        <tr>
          <td colspan="2" align="center" style="font-size: 25px">
            需求发布填报表
          </td>
        </tr>
        <tr>
          <td align="right" width="200">需求名称：</td>
          <td align="left"><input type="text" class="intxt" name="title" /></td>
        </tr>
        <tr>
          <td align="right">单位（个人）名称：</td>
          <td align="left">
            <input type="text" class="intxt" name="unit" />
          </td>
        </tr>
        <tr>
          <td align="right">联系人：</td>
          <td align="left">
            <input type="text" class="intxt" name="nickname" />
          </td>
        </tr>
        <tr>
          <td align="right">联系电话：</td>
          <td align="left">
            <input type="number" class="intxt" name="phone" maxlength="11" />
          </td>
        </tr>
        <tr>
          <td align="right">需求类型：</td>
          <td align="left">
            &nbsp;
            <input type="radio"  name="need_type" checked="checked" value="产品需求" />
            &nbsp;
            <label>产品需求</label>
            
            &nbsp;
            <input type="radio"  name="need_type" value="技术需求" />
            &nbsp;
            <label>技术需求</label
            >
            &nbsp;<input type="radio"  name="need_type" value="人才需求" />
            &nbsp;
            <label>人才需求</label>

          </td>
        </tr>

        <tr>
          <td align="right">发布日期：</td>
          <td align="left">
            <input type="date" class="intxt" name="fill_in_date" />
          </td>
        </tr>

        <tr>
          <td align="right">需求描述：</td>
          <td align="left" height="200">
            <textarea
              style="resize: none"
              class="inarea"
              name="content"
              id="content"
              
            ></textarea>
          </td>
        </tr>
        <tr>
          <td align="right">具体要求：</td>
          <td align="left"  height="150">
            <textarea
              style="resize: none"
              class="inarea"
              name="requirement"
              id="requirement"
            ></textarea>
          </td>
        </tr>
        <tr>
          <td colspan="2">
            <input type="submit" class="in" name="submit" value="发布"/>&nbsp;
            <input type="reset" class="in" name="reset"/>
          </td>
        </tr>
      </table>
    </form>
  </div>
</template>

<script>
export default {
  name: "send",
  data() {
    return {
      msg: "123",
    };
  },
  methods: {
    register() {
      this.$router.replace("/login");
    },
  },
};
</script>

<style scoped>
.form1 {
  width: 80%;
  margin: 30px auto;
 
}
table {
  width: 100%;
}
.intxt {
  width: 300px;
  height: 25px;
}
.inarea {
  width: 400px;
  height: 150px;
}
tr {
  height: 50px;
}
button{
    width: 50px;
    height: 40px;
    font-size: 18px;

}
.in{
   width:70px;
    height: 35px;
    font-size: 18px; 
    background: #898c94;
    border: none;
    border-radius: 15px;
    color: rgb(255, 255, 255);
}

</style>