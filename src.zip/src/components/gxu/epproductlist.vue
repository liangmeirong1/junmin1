
<template>
  <div class="content1">
    <div class="a1"><div><el-divider content-position="left">防疫产品</el-divider></div></div>

    <ul class="good-list">
      <li v-for="item of infolist" :key="item.id" @click="handel(item.id)">
        <div class="left con">
          <div class="name">
            <i class="el-icon-s-cooperation" style="font-size:20px;color:#807e7e;"></i>&nbsp;&nbsp;{{ item.title }}
          </div>
        </div>
        <div class="right">{{ item.time }}</div>
      </li>
    </ul>
    <div class="pagination1">
      <el-pagination background 
      layout="prev, pager, next,total" 
      :total="60">
      </el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: "epproductlist",
  components: {},
  methods: {
    handel(id) {
      this.$router.push({
        name: "epproductdetails",
        params: { id: id },
      });
    },
  },
  data() {
    return {
      infolist: [
        {
          id: "001",
          title: "抗疫黑科技-热成像人体测温仪",
          time: "12月30日",
        },
        {
          id: "002",
          title: "抗疫黑科技-热成像人体测温仪",
          time: "12月30日",
        },
        {
          id: "003",
          title: "抗疫黑科技-热成像人体测温仪",
          time: "12月30日",
        },
        {
          id: "004",
          title: "抗疫黑科技-热成像人体测温仪",
          time: "12月30日",
        },
        {
          id: "005",
          title: "抗疫黑科技-热成像人体测温仪",
          time: "12月30日",
        },
        {
          id: "006",
          title: "抗疫黑科技-热成像人体测温仪",
          time: "12月30日",
        },
        {
          id: "007",
          title: "大扩展比方舱移动医院系统集成技术",
          time: "12月30日",
        },
      ],
    };
  },
};
</script>
<style  scoped>
.content1 {
  width: 100%;
}
.a1{
 margin-top: 15px;

}
.a1 >>>.el-divider__text {
    position: absolute;
  
   background-color:#323b50 ;
   height: 40px;
   line-height: 40px;
    padding: 0 20px;
    color:  #ffffff;
    font-size: 16px;
}
/* .a1 div{
  width: 150px;
  background: #323b50;
} */

.good-list li {
  cursor: pointer;
  display: flex;
  padding: 10px;
  border-bottom: 1px dotted rgb(199, 199, 199);
  color: rgb(145, 143, 143)!important;
  font-size: 14px;
  height: 40px;
}

 .name:hover{
  color: #8d8d8d!important; 
} 
.name .el-icon-box{
  color: #807e7e;
}
.con {
  flex: 1;
}
.left {
  text-align: left;
  margin-left: 10px;
  padding: 10px 0 0 0;
}
.name {
  color: black;
  font-size: 16px;
}
.appNum{
  margin-top: 8px;
}
.tag {
  line-height: 24px;
  display: inline-block;
  vertical-align: middle;
  padding: 0 8px;
  border-radius: 4px;
  font-size: 13px;
  margin-left: 10px;
  color: #e6ac2e;
  background: #fceaea;
}
.iconfont5 {
  font-size: 17px;
  color: #323b50;
}
.pagination1 {
  height: 70px;
  float: right;
  padding-top: 25px;

  align-content: right;
}

.pagination1
  >>> .el-pagination.is-background
  .el-pager
  li:not(.disabled).active {
  background-color: #323b50;
  color: #fff;
}
.pagination1 >>> .el-pagination.is-background .el-pager li:hover {
  color: #000000;
}
/* .pic {
width:150px;
height: 100px;
}
.pic img{
  width: 100%;
 
} */
</style>