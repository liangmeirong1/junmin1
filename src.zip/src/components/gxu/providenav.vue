
<template>
 <div class="nav1">
       <div class="area" >设备类型:</div>
      <ul class="selectMenu">
         <el-row>
        <el-button ref="a11" type="info" size="medium" plain @click="handleClickNav('all')" :style="styleObject">全部</el-button>
        <el-button type="info" size="medium" plain  @click="handleClickNav('js')">军工实验设施</el-button>
        <el-button type="info" size="medium" plain @click="handleClickNav('jd')">军工大型科研仪器</el-button>
        <el-button type="info" size="medium" plain @click="handleClickNav('gf')">国防最高标准器具</el-button>
        </el-row>

      </ul>
    </div>
</template>

<script>
/* import top from '../components/top' */

export default {
  name: "providenav",
  components: {},
  data() {
    return {
      styleObject: {
    color: 'white',
    background:"#909399",
  }}
  },
  methods: {
    handleClickNav (params) {
      this.styleObject=null;
      this.$emit('changeNav', params)
    }
  }
};
</script>
<style scoped>
.nav1 {
  height: 80px;
  line-height: 80px;
  width: 100%;
  background: rgb(235, 235, 235);
  display: flex;
  border-bottom: 3px solid #323b50;

  
}
  .selectMenu >>> .el-button--medium {
  margin:5px;

}
.selectMenu{
  text-align: left;
  display: flex;
  flex-flow: row wrap;
}
.area{
  padding:0 0 0 15px; 
  width: 80px;
 
  }
  .selectMenu >>> .el-button--info{
    color:#323b50;
    font-size: 15px;

}

 





</style>