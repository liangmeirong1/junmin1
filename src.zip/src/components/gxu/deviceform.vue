<template>
  <div class="form1">
    <form action="#" method="post" id="formMsg">
      <table border="0" cellpadding="" cellspacing="0">
        <tr>
          <td colspan="2" align="center" style="font-size: 25px">
            供给发布填报表
          </td>
        </tr>
        <tr>
          <td align="right" class="intxt1">供给名称：</td>
          <td align="left">
            <input type="text" class="intxt" name="title" required />
          </td>
        </tr>
        <tr>
          <td align="right" class="intxt1">单位（个人）名称：</td>
          <td align="left">
            <input type="text" class="intxt" name="unit" required />
          </td>
        </tr>
        <tr>
          <td align="right" class="intxt1">安装地点：</td>
          <td align="left">
            <input type="text" class="intxt" name="unit" required />
          </td>
        </tr>
          <tr>
          <td align="right" class="intxt1"> 价格（人民币/万元）：</td>
          <td align="left">
            <input type="text" class="intxt" name="unit" required />
          </td>
        </tr>
          <tr>
          <td align="right" class="intxt1">服务费（人民币/万元）：</td>
          <td align="left">
            <input type="text" class="intxt" name="unit" required  placeholder="（人民币/万元）"/>
          </td>
        </tr>

        <tr>
          <td align="right" class="intxt1">联系人：</td>
          <td align="left">
            <input type="text" class="intxt" name="nickname" required />
          </td>
        </tr>
        <tr>
          <td align="right" class="intxt1">联系电话：</td>
          <td align="left">
            <input
              type="number"
              class="intxt"
              name="phone"
              maxlength="11"
              required
            />
          </td>
        </tr>
        <tr>
          <td align="right" class="intxt1">设备类型：</td>
          <td align="left">
            &nbsp;
            <select>
              <option value="all">全部</option>
              <option value="fx">军工实验设施</option>
              <option value="jg">军工大型科研仪器</option>
              <option value="dz">国防最高标准器具</option>
           
            </select>
          </td>
        </tr>

        <tr>
          <td align="right" class="intxt1">发布日期：</td>
          <td align="left">
            <input type="date" class="intxt" name="fill_in_date" />
          </td>
        </tr>
        <tr>
          <td align="right">设备描述：</td>
          <td align="left" height="200">
            <textarea
              style="resize: none"
              class="inarea"
              name="content"
              id="content"
            ></textarea>
          </td>
        </tr>

        <tr>
          <td colspan="2">
            <input type="submit" class="in" name="submit" value="发布" />&nbsp;
            <input type="reset" class="in" name="reset" />
          </td>
        </tr>
      </table>
    </form>
   
  </div>
</template>

<script>
export default {
  name: "send",
  data() {
    return {
      msg: "123",
    };
  },
  methods: {
    register() {
      this.$router.replace("/login");
    },
  
  },
};
</script>

<style scoped>
.form1 {
  width: 90%;
  margin: 30px auto;
}
table {
  width: 100%;
}
.intxt {
  width: 300px;
  height: 25px;
}
.intxt1{
  width:200px;
}

select {
  height: 30px;
}
.inarea {
  width: 400px;
  height: 150px;
}
tr {
  height: 50px;
}
button {
  width: 50px;
  height: 40px;
  font-size: 18px;
}
.in {
  width: 70px;
  height: 35px;
  font-size: 18px;
  background: #898c94;
  border: none;
  border-radius: 15px;
  color: rgb(255, 255, 255);
}
</style>