
<template>
  <div class="content1">
    <ul class="good-list">
      <li v-for="item of infolist" :key="item.id" @click="handel(item.id)">
        <div class="pic">
          <img :src="item.img" />
        </div>
        <div class="left">
          <div class="name">
            {{ item.title }}
          </div>
          <div>应用领域：{{ item.area }}</div>
        </div>
      </li>
    </ul>
    <div class="pagination1">
      <el-pagination background layout="prev, pager, next,total" :total="60">
      </el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: "content2",
  components: {},
  methods: {
    handel(id) {
      this.$router.push({
        name: "providetail",
        params: { id: id },
      });
    },
  },
  data() {
    return {
      infolist: [
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "001",
          title: "遥控深海采矿车",
          type: "产品供应",
          area: "应急救援",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "002",
          title: "遥控深海采矿车",
          type: "产品供应",
          area: "应急救援",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "001",
          title: "遥控深海采矿车",
          type: "产品供应",
          area: "应急救援",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "002",
          title: "遥控深海采矿车",
          type: "产品供应",
          area: "应急救援",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "001",
          title: "遥控深海采矿车",
          type: "产品供应",
          area: "应急救援",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "002",
          title: "遥控深海采矿车",
          type: "产品供应",
          area: "应急救援",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "001",
          title: "遥控深海采矿车",
          type: "产品供应",
          area: "应急救援",
          time: "12月30日",
        },
        {
          img: "http://file.gzjmrh.com/upload/20181119/201811191538598784.png",
          id: "002",
          title: "遥控深海采矿车",
          type: "产品供应",
          area: "应急救援",
          time: "12月30日",
        },
      ],
    };
  },
};
</script>
<style  scoped>
.content1 {
  width: 95%;
  margin: 0 auto;
}

.good-list {
  display: flex;
  flex-flow: row wrap;
  justify-content: start;
}

.good-list li {
  width: 30%;
  box-sizing: border-box;
  margin: 0 1.6%;
  padding: 15px;
  border: 0.5px solid rgb(199, 199, 199);
  color: rgb(145, 143, 143);
  font-size: 14px;
  margin-top: 20px;
}
.good-list li:hover {
  box-shadow: 0 0 5px rgb(145, 143, 143) inset;
}
.pic img {
  width: 95%;
}

.pagination1 {
  height: 70px;
  float: right;
  padding-top: 25px;
  align-content: right;
}

.pagination1
  >>> .el-pagination.is-background
  .el-pager
  li:not(.disabled).active {
  background-color: #323b50;
  color: #fff;
}
.pagination1 >>> .el-pagination.is-background .el-pager li:hover {
  color: #000000;
}
</style>