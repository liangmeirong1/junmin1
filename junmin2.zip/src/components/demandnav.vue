
<template>
 <div class="nav1">
      <ul class="selectMenu">
        <div class="area" >服务领域 :</div>
        <li @click="handleClickNav('all')">全部</li>
        <li @click="handleClickNav('nh')">南海区</li>
        <li @click="handleClickNav('sd')">顺德区</li>
        <li @click="handleClickNav('gm')">高明区</li>
        <li @click="handleClickNav('ss')">三水区</li>
        <li @click="handleClickNav('qt')">其他</li>
      </ul>
    </div>
</template>

<script>
/* import top from '../components/top' */

export default {
  name: "demandnav",
  components: {},
  /* data() {
    return {
       name: '11'}
  }, */
  methods: {
    handleClickNav (params) {
      this.$emit('changeNav', params)
    }
  }
};
</script>
<style scoped>
.nav1 {
  height: 70px;
  width: 100%;
  background: rgb(235, 235, 235);
  display: flex;
  border-bottom: 3px solid #323b50;
  align-items: baseline;
  
}
.selectMenu{
  height:100%;
  width: 100%;
  display: flex;
  align-items: center;
  flex-flow: row wrap;
}
.area{
  padding-left:15px ; 
  width: 100px;
 
  }
.selectMenu li{
  padding: 3px 6px;
  border-radius: 8px;
  font-size: 15px;
  margin-left: 15px;
  border: 1px solid rgb(153, 151, 151);
}
.selectMenu li:hover{
    color: rgb(0, 0, 0) !important;
    background-color: rgb(211, 211, 211) !important;
    
}



</style>