
<template>
  <div class="top">
    <div class="con">
      <img
        src="https://www.hnjmrh.gov.cn/file/M00+01+04+rBAHAlw4BZ-AaQ9tAAB0-JM4h4I228.jpg"
      />
      <div class="detail">
        <h2>遥控深海采矿车</h2>
        <div class="pa">应用领域：应急救援</div>
        <div class="pa">安装地点：南海区</div>
        <div class="pa">数量：3<span>台</span></div>
        <div class="pa">联系电话：134141414556</div>
        <div class="pa">联系人：梁某人</div>
        <div class="liji">立即对接</div>
      </div>
    </div>
     <div class="infodetail">
      <div class="top1"><div class="span1">设备详情</div></div>
      <div class="detail1">1.可视化激光码型测试仪。波长范围：200～1600nm；码型：3～10位编码； 重频：≤100Hz；脉冲宽度：≤15ns。 2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。 3.资质要求：具有武器装备承制单位资格。1.可视化激光码型测试仪。波长范围：200～1600nm；码型：3～10位编码； 重频：≤100Hz；脉冲宽度：≤15ns。 2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。 3.资质要求：具有武器装备承制单位资格。1.可视化激光码型测试仪。波长范围：200～1600nm；码型：3～10位编码； 重频：≤100Hz；脉冲宽度：≤15ns。 2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。 3.资质要求：具有武器装备承制单位资格。1.可视化激光码型测试仪。波长范围：200～1600nm；码型：3～10位编码； 重频：≤100Hz；脉冲宽度：≤15ns。 2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。 3.资质要求：具有武器装备承制单位资格。1.可视化激光码型测试仪。波长范围：200～1600nm；码型：3～10位编码； 重频：≤100Hz；脉冲宽度：≤15ns。 2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。 3.资质要求：具有武器装备承制单位资格。</div>
    </div>
  </div>
</template>

<script>
/* import top from '../components/top' */

export default {
  name: "details2",
  components: {},
  data() {
    return {
      name: "user",
      params: { userId },
    };
  },
};
</script>
<style scoped>
.top {
  width: 100%;


  padding: 15px;
}
.con{
width: 100%;
  display: flex;

}
.top img {
  width: 40%;
}
h2 {
  color: #323b50;
}
.pa {
  padding: 3px;
}
.liji {
  width: 95px;
  line-height: 34px;
  color: rgb(255, 255, 255);
  background: #323b50;
  text-align: center;
  border-radius: 18px;
  margin-top: 7px;
}
.detail {
  text-align: left;
  padding-left: 18px;
  flex: 1;
  color: #78797c;
}
.infodetail {
  border:1px solid    #e2e2e2;
  margin-top: 25px;

}
.infodetail .top1{
  text-align: left;
  height: 40px;
  background: #e2e2e2;
  color: rgb(255, 255, 255);
  line-height: 40px;

}
.infodetail .top1 .span1{
text-align: center;
  width: 110px;
  background: #323b50;


}
.infodetail .detail1{
  padding: 20px;
}
</style>