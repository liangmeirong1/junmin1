
<template>
 <div class="nav1">
       <div class="area" >应用领域:</div>
      <ul class="selectMenu">
        <li @click="handleClickNav('all')">全部</li>
        <li @click="handleClickNav('nh')">分析仪器</li>
        <li @click="handleClickNav('sd')">激光器</li>
        <li @click="handleClickNav('gm')">电子测量仪器</li>
        <li @click="handleClickNav('ss')">计量仪器</li>
        <li @click="handleClickNav('qt')">核仪器</li>
        <li @click="handleClickNav('sd')">特种检测仪器</li>
        <li @click="handleClickNav('gm')">测试仪器</li>
        <li @click="handleClickNav('ss')">其他仪器</li>

      </ul>
    </div>
</template>

<script>
/* import top from '../components/top' */

export default {
  name: "providenav",
  components: {},
  /* data() {
    return {
       name: '11'}
  }, */
  methods: {
    handleClickNav (params) {
      this.$emit('changeNav', params)
    }
  }
};
</script>
<style scoped>
.nav1 {
  height: 100px;
  width: 100%;
  background: rgb(235, 235, 235);
  display: flex;
  border-bottom: 3px solid #323b50;
  align-items: baseline;
  
}
.selectMenu{
  height:100%;
 
  display: flex;
  align-items: center;
  flex-flow: row wrap;
}
.area{
  padding-left:15px ; 
  width: 100px;
 
  }
.selectMenu li{
  padding: 3px 6px;
  border-radius: 8px;
  font-size: 15px;
  margin-left: 15px;
  border: 1px solid rgb(153, 151, 151);
}
.selectMenu li:hover{
    color: rgb(0, 0, 0) !important;
    background-color: rgb(211, 211, 211) !important;
    
}



</style>