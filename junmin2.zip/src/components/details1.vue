
<template>
  <div class="content1">
    <div class="top">
      <div class="title">
        <span class="iconfont5 icon-fasong"></span>多箱型自动码垛机
      </div>
      <div class="liji">立即对接</div>
    </div>
    <table class="table" border="1">
      <tbody>
        <tr>
          <td class="td_head">信息来源</td>
          <td colspan="3">佛山市军民融合公共服务平台</td>
        </tr>
        <tr>
          <td class="td_head">需求类型</td>
          <td>产品需求</td>
          <td class="td_head">发布日期</td>
          <td>2020-03-31</td>
        </tr>
        <tr>
          <td class="td_head">联系人</td>
          <td>
            梁***
            <span style=""
              >(请<a
                href="javascript:void(0)"
                onclick="<!-- redirectLogin('/newweb/demand/detail/4831' -->)"
                style="cursor: pointer; color: red"
                >登录</a
              >后查看)</span
            >
          </td>
          <td class="td_head">联系方式</td>
          <td>183***7</td>
        </tr>
      </tbody>
    </table>
    <div class="infodetail">
      <div class="top1"><div class="span1">需求介绍</div></div>
      <div class="detail">1.可视化激光码型测试仪。波长范围：200～1600nm；码型：3～10位编码； 重频：≤100Hz；脉冲宽度：≤15ns。 2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。 3.资质要求：具有武器装备承制单位资格。1.可视化激光码型测试仪。波长范围：200～1600nm；码型：3～10位编码； 重频：≤100Hz；脉冲宽度：≤15ns。 2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。 3.资质要求：具有武器装备承制单位资格。1.可视化激光码型测试仪。波长范围：200～1600nm；码型：3～10位编码； 重频：≤100Hz；脉冲宽度：≤15ns。 2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。 3.资质要求：具有武器装备承制单位资格。1.可视化激光码型测试仪。波长范围：200～1600nm；码型：3～10位编码； 重频：≤100Hz；脉冲宽度：≤15ns。 2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。 3.资质要求：具有武器装备承制单位资格。1.可视化激光码型测试仪。波长范围：200～1600nm；码型：3～10位编码； 重频：≤100Hz；脉冲宽度：≤15ns。 2.根据本次需求响应对接结果，将视情组织资格预审，确定分包项目。 3.资质要求：具有武器装备承制单位资格。</div>
    </div>
  </div>
</template>

<script>
/* import top from '../components/top' */

export default {
  name: "details1",
  components: {},
  data() {
    return {
      name: "user",
      params: { userId },
    };
  },
};
</script>
<style scoped>
* {
  box-sizing: border-box;
}
.content1 {
  width: 95%;
  margin: 25px auto;
  font-size: 16px;
}
.top {
  display: flex;
}
.title {
  flex: 1;
  text-align: left;
  font-size: 20px;
}
.iconfont5 {
  font-size: 17px;
  color: #323b50;
  margin-right: 10px;
}
.liji {
  width: 100px;
  line-height: 36px;
  color: rgb(255, 255, 255);
  background: #323b50;
  text-align: center;
  border-radius: 18px;
}
tbody {
  display: table-row-group;
  vertical-align: middle;
  text-align: left;
}
td {
  padding-left: 25px;
}
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  margin-top: 25px;
  height: 150px;
}
.table .td_head {
  color: #333333;
  width: 175px;
  background:  #ebebeb;
}
.infodetail {
  border:1px solid   #dadada;
  margin-top: 25px;

}
.infodetail .top1{
  text-align: left;
  height: 40px;
  background: #dadada;
  color: rgb(255, 255, 255);
  line-height: 40px;

}
.infodetail .top1 .span1{
text-align: center;
  width: 110px;
  background: #323b50;


}
.infodetail .detail1{
  padding: 20px;
}

</style>