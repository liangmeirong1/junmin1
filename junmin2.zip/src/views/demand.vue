<template>

  <div id="demand">
    <div class="left"><StraightTab /></div>

    <div class="content">
     <demandnav  @changeNav="handleChangeNav"/>
     <content1 :list="serverList"/>

    </div>
 
  </div>
 
    
</template>

<script>
import StraightTab from "../components/StraightTab";
 import content1 from "../components/content1"
  import demandnav from "../components/demandnav"
import axios from 'axios'

export default {
  name: "demand",
  components: { StraightTab,demandnav,content1},
  data() {
    return {
      id: null,
      field: 'all',
      page: {
      pageSize: 10,
      pageNum: 1,
      total: 0
      },
      serverList: []
    };
  },
  mounted() {
    this.id = this.$route.params.id
    this.getList()
  },
  watch: {
    $route:{
      handler(nv, ov){
        this.id = this.$route.params.id
        this.getList()
      },
      // 深度观察监听
      deep: true
    }
  },
  methods: {
    getList () {
      axios.get('/api/getData', {
        params: {
          id: this.id,
          field: this.field,
          pageSize: this.page.pageSize,
          pageNum: this.page.pageNum
        }
      }).then(res => {
        if (res) {
          this.serverList = res.data.list
        } else {
          console.log('没有数据')
        }
      })
    },
  
    handleChangeNav (params) {
      this.field = params
      this.getList()
    }

  }
};
</script>
<style scoped>
#demand {
  width: 80%;
  position: relative;
  left: 10%;
 /*  border: 1px solid rgb(235, 235, 235); */
  display: flex;
  overflow: hidden;
  margin-top: 10px;
}
.left {
  width: 21%;
}
.content {
  border: 1px solid rgb(235, 235, 235);
  flex: 1;
  margin-left: 15px;
  
}
</style>