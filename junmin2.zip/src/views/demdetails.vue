<template>
  <div id="demand">
    <div class="left"><StraightTab /></div>

    <div class="content">
     <details1></details1>
     
    </div>
 
  
  </div>
</template>

<script>
import StraightTab from "../components/StraightTab";
 import details1 from "../components/details1" 

export default {
  name: "demdetails",
  components: { StraightTab,details1},
  data() {
    return {
     
    };
  },
mounted() {
  alert( this.$route.params.id);
    this.id = this.$route.params.id
    this.getList()
  },
  watch: {
    $route:{
      handler(nv, ov){
        this.id = this.$route.params.id
        this.getList()
      },
      // 深度观察监听
      deep: true
    }
  },
  methods: {
    getList () {
      axios.get('/api/getData', {
        params: {
          id: this.id,
          field: this.field,
          pageSize: this.page.pageSize,
          pageNum: this.page.pageNum
        }
      }).then(res => {
        if (res) {
          this.serverList = res.data.list
        } else {
          console.log('没有数据')
        }
      })
    },}
};
</script>
<style scoped>
#demand {
  width: 80%;
  position: relative;
  left: 10%;
  border: 1px solid rgb(235, 235, 235);
  display: flex;
  overflow: hidden;
  margin-top: 10px;
}
.left {
  width: 21%;
}
.content {
  border: 1px solid rgb(235, 235, 235);
  flex: 1;
  margin-left: 15px;
  
}
</style>