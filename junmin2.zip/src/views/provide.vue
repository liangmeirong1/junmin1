<template>
  <div id="demand">
    <div class="left"><StraightTab /></div>                                                
    <div class="content">
      <providenav />
      <content2 />
    </div>
  </div>
</template>

<script>
import StraightTab from "../components/StraightTab";
import content2 from "../components/content2";
import providenav from "../components/providenav";

import axios from "axios";

export default {
  name: "demand",
  components: { StraightTab, content2, providenav },
};
</script>
<style scoped>
#demand {
  width: 80%;
  position: relative;
  left: 10%;
  display: flex;
  overflow: hidden;
  margin-top: 10px;
}
.left {
  width: 21%;
}
.content {
  border: 1px solid rgb(235, 235, 235);
  flex: 1;
  margin-left: 15px;
}
</style>
<!--   data() {
    return {
      id: null,
      field: 'all',
      page: {
      pageSize: 10,
      pageNum: 1,
      total: 0
      },
      serverList: []
    };
  },
  mounted() {
    this.id = this.$route.params.id
    this.getList()
  },
  watch: {
    $route:{
      handler(nv, ov){
        this.id = this.$route.params.id
        this.getList()
      },
      // 深度观察监听
      deep: true
    }
  },
  methods: {
    getList () {
      axios.get('/api/getData', {
        params: {
          id: this.id,
          field: this.field,
          pageSize: this.page.pageSize,
          pageNum: this.page.pageNum
        }
      }).then(res => {
        if (res) {
          this.serverList = res.data.list
        } else {
          console.log('没有数据')
        }
      })
    },
  
    handleChangeNav (params) {
      this.field = params
      this.getList()
    }

  }  */-->